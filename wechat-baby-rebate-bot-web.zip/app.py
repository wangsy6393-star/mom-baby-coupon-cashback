# -*- coding: utf-8 -*-
"""
母婴返利机器人网页版后端API
"""
import os
import sys
import json
import logging
import time
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, render_template, redirect, url_for, session
from flask_cors import CORS
from pymongo import MongoClient
from bson.objectid import ObjectId
import requests
from urllib.parse import urlparse, parse_qs
import re

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 创建Flask应用
app = Flask(__name__, static_folder='static', template_folder='templates')
app.config['SECRET_KEY'] = os.urandom(24)
CORS(app)

# 数据库配置
MONGO_URI = os.getenv('MONGO_URI', 'mongodb://localhost:27017/baby_rebate_bot')
client = MongoClient(MONGO_URI)
db = client.get_default_database()

# 支持的品牌列表
SUPPORTED_BRANDS = [
    'babycare', '好奇', '大王', '新贝', '尤妮佳', '露安适',
    '帮宝适', '花王', 'moony', '可优比', '好孩子', '贝亲'
]

# 返利比例配置
REBATE_RATES = {
    'taobao': {
        'default': 0.05,  # 默认5%
        'diaper': 0.08,   # 纸尿裤8%
        'mama': 0.06,     # 孕妈用品6%
        'baby': 0.07      # 婴儿用品7%
    },
    'pdd': {
        'default': 0.06,
        'diaper': 0.09,
        'mama': 0.07,
        'baby': 0.08
    },
    'douyin': {
        'default': 0.07,
        'diaper': 0.10,
        'mama': 0.08,
        'baby': 0.09
    },
    'jd': {
        'default': 0.04,
        'diaper': 0.07,
        'mama': 0.05,
        'baby': 0.06
    }
}

# 提现配置
MIN_WITHDRAWAL_AMOUNT = 10.0  # 最小提现金额10元
WITHDRAWAL_FEE = 0.1  # 提现手续费10%

# 商品类别关键词
PRODUCT_CATEGORIES = {
    'diaper': [
        '纸尿裤', '尿不湿', '纸尿片', '拉拉裤', '尿片', '尿裤',
        'diaper', 'nappy', 'pull-up', 'training pants'
    ],
    'mama': [
        '孕妇', '孕妈', '待产', '产妇', '孕期', '哺乳期',
        'pregnancy', 'maternity', 'postpartum', 'breastfeeding'
    ],
    'baby': [
        '婴儿', '宝宝', '新生儿', '幼儿', '童装', '童鞋',
        'baby', 'infant', 'newborn', 'toddler', 'children'
    ]
}

# 平台名称映射
PLATFORM_NAMES = {
    'taobao': '淘宝/天猫',
    'pdd': '拼多多',
    'douyin': '抖音',
    'jd': '京东'
}

# 模拟商品数据（实际项目中应从各平台API获取）
MOCK_PRODUCTS = [
    {
        'id': '1',
        'name': 'Babycare纸尿裤超薄透气干爽婴儿尿不湿S码',
        'image': 'https://p3-flow-imagex-sign.byteimg.com/tos-cn-i-a9rns2rl98/rc/pc/super_tool/b49a9cd31b7c4354a2d50f7335368f45~tplv-a9rns2rl98-image.image?lk3s=8e244e95&rcl=202604191604424353518307EAF3E3646A&rrcfp=f06b921b&x-expires=1779177946&x-signature=bpTKxrjTR82ptwzw3I%2BGFs59UJg%3D',
        'price': 199.00,
        'original_price': 299.00,
        'coupon_amount': 100.00,
        'rebate_amount': 15.92,
        'platform': 'taobao',
        'category': 'diaper',
        'brand': 'babycare',
        'url': 'https://item.taobao.com/item.htm?id=1234567890'
    },
    {
        'id': '2',
        'name': '好奇金装纸尿裤M码168片 婴儿尿不湿',
        'image': 'https://p3-flow-imagex-sign.byteimg.com/tos-cn-i-a9rns2rl98/rc/pc/super_tool/b49a9cd31b7c4354a2d50f7335368f45~tplv-a9rns2rl98-image.image?lk3s=8e244e95&rcl=202604191604424353518307EAF3E3646A&rrcfp=f06b921b&x-expires=1779177946&x-signature=bpTKxrjTR82ptwzw3I%2BGFs59UJg%3D',
        'price': 258.00,
        'original_price': 358.00,
        'coupon_amount': 100.00,
        'rebate_amount': 20.64,
        'platform': 'jd',
        'category': 'diaper',
        'brand': '好奇',
        'url': 'https://item.jd.com/100008368345.html'
    },
    {
        'id': '3',
        'name': '大王天使纸尿裤L54片 婴儿尿不湿',
        'image': 'https://p3-flow-imagex-sign.byteimg.com/tos-cn-i-a9rns2rl98/rc/pc/super_tool/b49a9cd31b7c4354a2d50f7335368f45~tplv-a9rns2rl98-image.image?lk3s=8e244e95&rcl=202604191604424353518307EAF3E3646A&rrcfp=f06b921b&x-expires=1779177946&x-signature=bpTKxrjTR82ptwzw3I%2BGFs59UJg%3D',
        'price': 328.00,
        'original_price': 428.00,
        'coupon_amount': 100.00,
        'rebate_amount': 26.24,
        'platform': 'pdd',
        'category': 'diaper',
        'brand': '大王',
        'url': 'https://mobile.yangkeduo.com/goods.html?goods_id=123456789'
    }
]

# 模拟用户数据
MOCK_USER = {
    '_id': ObjectId('5f8d3a7e9c9d440001a1b2c3'),
    'username': 'test_user',
    'nickname': '宝妈用户',
    'avatar': 'https://p3-flow-imagex-sign.byteimg.com/tos-cn-i-a9rns2rl98/rc/pc/super_tool/436d5af68b334b29abca453e8cac248e~tplv-a9rns2rl98-image.image?lk3s=8e244e95&rcl=202604191604424353518307EAF3E3646A&rrcfp=f06b921b&x-expires=1779177969&x-signature=t9d%2F6NIq3mrce%2BVe2Ug%2F5ycVJCY%3D',
    'balance': 150.50,
    'created_at': datetime.now(),
    'updated_at': datetime.now()
}

# 模拟订单数据
MOCK_ORDERS = [
    {
        '_id': ObjectId('5f8d3a7e9c9d440001a1b2c4'),
        'user_id': ObjectId('5f8d3a7e9c9d440001a1b2c3'),
        'platform': 'taobao',
        'order_id': 'TB1234567890',
        'item_id': '1',
        'item_name': 'Babycare纸尿裤超薄透气干爽婴儿尿不湿S码',
        'item_image': 'https://p3-flow-imagex-sign.byteimg.com/tos-cn-i-a9rns2rl98/rc/pc/super_tool/b49a9cd31b7c4354a2d50f7335368f45~tplv-a9rns2rl98-image.image?lk3s=8e244e95&rcl=202604191604424353518307EAF3E3646A&rrcfp=f06b921b&x-expires=1779177946&x-signature=bpTKxrjTR82ptwzw3I%2BGFs59UJg%3D',
        'original_price': 299.00,
        'coupon_amount': 100.00,
        'actual_pay': 199.00,
        'rebate_amount': 15.92,
        'status': 'rebated',
        'created_at': datetime.now() - timedelta(days=5),
        'confirmed_at': datetime.now() - timedelta(days=2),
        'rebated_at': datetime.now() - timedelta(days=2)
    },
    {
        '_id': ObjectId('5f8d3a7e9c9d440001a1b2c5'),
        'user_id': ObjectId('5f8d3a7e9c9d440001a1b2c3'),
        'platform': 'jd',
        'order_id': 'JD1234567890',
        'item_id': '2',
        'item_name': '好奇金装纸尿裤M码168片 婴儿尿不湿',
        'item_image': 'https://p3-flow-imagex-sign.byteimg.com/tos-cn-i-a9rns2rl98/rc/pc/super_tool/b49a9cd31b7c4354a2d50f7335368f45~tplv-a9rns2rl98-image.image?lk3s=8e244e95&rcl=202604191604424353518307EAF3E3646A&rrcfp=f06b921b&x-expires=1779177946&x-signature=bpTKxrjTR82ptwzw3I%2BGFs59UJg%3D',
        'original_price': 358.00,
        'coupon_amount': 100.00,
        'actual_pay': 258.00,
        'rebate_amount': 20.64,
        'status': 'confirmed',
        'created_at': datetime.now() - timedelta(days=10),
        'confirmed_at': datetime.now() - timedelta(days=1),
        'rebated_at': None
    },
    {
        '_id': ObjectId('5f8d3a7e9c9d440001a1b2c6'),
        'user_id': ObjectId('5f8d3a7e9c9d440001a1b2c3'),
        'platform': 'pdd',
        'order_id': 'PDD1234567890',
        'item_id': '3',
        'item_name': '大王天使纸尿裤L54片 婴儿尿不湿',
        'item_image': 'https://p3-flow-imagex-sign.byteimg.com/tos-cn-i-a9rns2rl98/rc/pc/super_tool/b49a9cd31b7c4354a2d50f7335368f45~tplv-a9rns2rl98-image.image?lk3s=8e244e95&rcl=202604191604424353518307EAF3E3646A&rrcfp=f06b921b&x-expires=1779177946&x-signature=bpTKxrjTR82ptwzw3I%2BGFs59UJg%3D',
        'original_price': 428.00,
        'coupon_amount': 100.00,
        'actual_pay': 328.00,
        'rebate_amount': 26.24,
        'status': 'pending',
        'created_at': datetime.now() - timedelta(days=1),
        'confirmed_at': None,
        'rebated_at': None
    }
]

# 模拟提现记录
MOCK_WITHDRAWALS = [
    {
        '_id': ObjectId('5f8d3a7e9c9d440001a1b2c7'),
        'user_id': ObjectId('5f8d3a7e9c9d440001a1b2c3'),
        'amount': 100.00,
        'actual_amount': 90.00,
        'fee': 10.00,
        'method': 'wechat',
        'status': 'completed',
        'created_at': datetime.now() - timedelta(days=15),
        'processed_at': datetime.now() - timedelta(days=14)
    },
    {
        '_id': ObjectId('5f8d3a7e9c9d440001a1b2c8'),
        'user_id': ObjectId('5f8d3a7e9c9d440001a1b2c3'),
        'amount': 50.00,
        'actual_amount': 45.00,
        'fee': 5.00,
        'method': 'alipay',
        'status': 'pending',
        'created_at': datetime.now() - timedelta(days=2),
        'processed_at': None
    }
]

# 工具函数
def parse_url(url):
    """解析URL，识别平台和商品ID"""
    try:
        # 处理短链接
        if url.startswith('http'):
            try:
                response = requests.head(url, allow_redirects=True, timeout=5)
                if response.status_code == 200:
                    url = response.url
            except:
                pass
        
        parsed_url = urlparse(url)
        netloc = parsed_url.netloc.lower()
        path = parsed_url.path
        query = parse_qs(parsed_url.query)
        
        # 淘宝/天猫
        if 'taobao.com' in netloc or 'tmall.com' in netloc:
            # 从路径中提取ID
            item_id_match = re.search(r'/(\d+)\.htm', path)
            if item_id_match:
                return {'platform': 'taobao', 'item_id': item_id_match.group(1)}
            
            # 从查询参数中提取ID
            if 'id' in query:
                return {'platform': 'taobao', 'item_id': query['id'][0]}
        
        # 拼多多
        elif 'pinduoduo.com' in netloc or 'pdd.com' in netloc:
            # 从路径中提取ID
            item_id_match = re.search(r'/goods/(\d+)', path)
            if item_id_match:
                return {'platform': 'pdd', 'item_id': item_id_match.group(1)}
            
            # 从查询参数中提取ID
            if 'goods_id' in query:
                return {'platform': 'pdd', 'item_id': query['goods_id'][0]}
        
        # 抖音
        elif 'douyin.com' in netloc or 'tiktok.com' in netloc:
            # 处理商品链接
            if '/product/' in path:
                item_id_match = re.search(r'/product/(\d+)', path)
                if item_id_match:
                    return {'platform': 'douyin', 'item_id': item_id_match.group(1)}
        
        # 京东
        elif 'jd.com' in netloc:
            # 从路径中提取ID
            item_id_match = re.search(r'/(\d+)\.html', path)
            if item_id_match:
                return {'platform': 'jd', 'item_id': item_id_match.group(1)}
            
            # 从查询参数中提取ID
            if 'sku' in query:
                return {'platform': 'jd', 'item_id': query['sku'][0]}
        
        return None
    except Exception as e:
        logger.error(f"解析URL失败: {str(e)}")
        return None

def check_brand(item_name, brand=None):
    """检查商品是否属于支持的品牌"""
    try:
        # 转换为小写进行比较
        item_name_lower = item_name.lower()
        
        # 检查品牌参数
        if brand:
            brand_lower = brand.lower()
            for supported_brand in SUPPORTED_BRANDS:
                if supported_brand.lower() in brand_lower:
                    return True
        
        # 检查商品名称中是否包含品牌关键词
        for supported_brand in SUPPORTED_BRANDS:
            if supported_brand.lower() in item_name_lower:
                return True
        
        return False
    except Exception as e:
        logger.error(f"检查品牌失败: {str(e)}")
        return False

def check_category(item_name, category=None):
    """检查商品类别"""
    try:
        # 转换为小写进行比较
        item_name_lower = item_name.lower()
        
        # 检查类别参数
        if category:
            category_lower = category.lower()
            for cat, keywords in PRODUCT_CATEGORIES.items():
                for keyword in keywords:
                    if keyword.lower() in category_lower:
                        return cat
        
        # 检查商品名称中是否包含类别关键词
        for cat, keywords in PRODUCT_CATEGORIES.items():
            for keyword in keywords:
                if keyword.lower() in item_name_lower:
                    return cat
        
        return "none"
    except Exception as e:
        logger.error(f"检查商品类别失败: {str(e)}")
        return "none"

def format_price(price):
    """格式化价格"""
    try:
        return f"¥{price:.2f}"
    except Exception as e:
        logger.error(f"格式化价格失败: {str(e)}")
        return "¥0.00"

def calculate_actual_withdrawal(amount):
    """计算实际提现金额（扣除手续费）"""
    try:
        fee = amount * WITHDRAWAL_FEE
        return round(amount - fee, 2), round(fee, 2)
    except Exception as e:
        logger.error(f"计算实际提现金额失败: {str(e)}")
        return 0.0, 0.0

# 路由定义
@app.route('/')
def index():
    """首页"""
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    """用户仪表盘"""
    # 模拟登录状态
    if 'user_id' not in session:
        session['user_id'] = str(MOCK_USER['_id'])
    
    # 获取用户信息
    user = MOCK_USER
    
    # 获取订单信息
    orders = MOCK_ORDERS
    
    # 获取提现记录
    withdrawals = MOCK_WITHDRAWALS
    
    # 获取热门商品
    popular_products = MOCK_PRODUCTS
    
    return render_template(
        'dashboard.html',
        user=user,
        orders=orders,
        withdrawals=withdrawals,
        popular_products=popular_products,
        min_withdrawal_amount=MIN_WITHDRAWAL_AMOUNT,
        withdrawal_fee=WITHDRAWAL_FEE * 100
    )

@app.route('/api/product/search', methods=['POST'])
def search_product():
    """搜索商品"""
    try:
        # 获取请求数据
        data = request.get_json()
        url = data.get('url', '')
        
        if not url:
            return jsonify({'error': '商品链接不能为空'}), 400
        
        # 解析链接
        parsed_url = parse_url(url)
        if not parsed_url:
            return jsonify({'error': '无法识别该商品链接，请检查链接是否正确'}), 400
        
        platform = parsed_url.get('platform')
        item_id = parsed_url.get('item_id')
        
        # 模拟商品信息（实际项目中应从各平台API获取）
        # 这里简单返回模拟数据中的第一个商品
        product = MOCK_PRODUCTS[0].copy()
        product['platform'] = platform
        product['id'] = item_id
        
        # 检查商品品牌
        if not check_brand(product.get('name', ''), product.get('brand', '')):
            return jsonify({
                'error': f'抱歉，该商品不在我们支持的品牌范围内。我们目前只支持以下品牌的母婴用品：{", ".join(SUPPORTED_BRANDS[:6])}等'
            }), 400
        
        # 检查商品类别
        category = check_category(product.get('name', ''))
        if category == 'none':
            return jsonify({'error': '抱歉，该商品不是母婴相关产品，我们只提供母婴用品的优惠信息'}), 400
        
        product['category'] = category
        
        # 格式化价格
        product['formatted_price'] = format_price(product['price'])
        product['formatted_original_price'] = format_price(product['original_price'])
        product['formatted_coupon_amount'] = format_price(product['coupon_amount'])
        product['formatted_rebate_amount'] = format_price(product['rebate_amount'])
        product['platform_name'] = PLATFORM_NAMES.get(platform, platform)
        
        return jsonify(product)
        
    except Exception as e:
        logger.error(f"搜索商品失败: {str(e)}")
        return jsonify({'error': '搜索商品失败，请稍后重试'}), 500

@app.route('/api/withdrawal/request', methods=['POST'])
def request_withdrawal():
    """申请提现"""
    try:
        # 模拟登录状态
        if 'user_id' not in session:
            return jsonify({'error': '请先登录'}), 401
        
        # 获取请求数据
        data = request.get_json()
        amount = data.get('amount', 0)
        method = data.get('method', 'wechat')
        
        # 验证提现金额
        if not amount or amount <= 0:
            return jsonify({'error': '提现金额必须大于0'}), 400
        
        if amount < MIN_WITHDRAWAL_AMOUNT:
            return jsonify({'error': f'最低提现金额为{MIN_WITHDRAWAL_AMOUNT}元'}), 400
        
        # 检查余额
        user = MOCK_USER
        if amount > user['balance']:
            return jsonify({'error': '余额不足'}), 400
        
        # 计算实际提现金额和手续费
        actual_amount, fee = calculate_actual_withdrawal(amount)
        
        # 模拟创建提现记录（实际项目中应保存到数据库）
        new_withdrawal = {
            '_id': ObjectId(),
            'user_id': user['_id'],
            'amount': amount,
            'actual_amount': actual_amount,
            'fee': fee,
            'method': method,
            'status': 'pending',
            'created_at': datetime.now(),
            'processed_at': None
        }
        
        # 模拟更新用户余额（实际项目中应更新数据库）
        user['balance'] -= amount
        user['updated_at'] = datetime.now()
        
        return jsonify({
            'success': True,
            'message': '提现申请已提交成功',
            'withdrawal': {
                'amount': amount,
                'actual_amount': actual_amount,
                'fee': fee,
                'method': method,
                'status': 'pending'
            }
        })
        
    except Exception as e:
        logger.error(f"申请提现失败: {str(e)}")
        return jsonify({'error': '申请提现失败，请稍后重试'}), 500

@app.route('/api/orders')
def get_orders():
    """获取订单列表"""
    try:
        # 模拟登录状态
        if 'user_id' not in session:
            return jsonify({'error': '请先登录'}), 401
        
        # 获取订单信息
        orders = MOCK_ORDERS
        
        # 格式化订单数据
        formatted_orders = []
        for order in orders:
            formatted_order = order.copy()
            formatted_order['formatted_original_price'] = format_price(order['original_price'])
            formatted_order['formatted_actual_pay'] = format_price(order['actual_pay'])
            formatted_order['formatted_rebate_amount'] = format_price(order['rebate_amount'])
            formatted_order['formatted_created_at'] = order['created_at'].strftime('%Y-%m-%d %H:%M:%S')
            formatted_order['platform_name'] = PLATFORM_NAMES.get(order['platform'], order['platform'])
            
            # 订单状态映射
            status_map = {
                'pending': '待确认',
                'confirmed': '已确认',
                'rebated': '已返利',
                'failed': '失败'
            }
            formatted_order['status_text'] = status_map.get(order['status'], order['status'])
            
            formatted_orders.append(formatted_order)
        
        return jsonify(formatted_orders)
        
    except Exception as e:
        logger.error(f"获取订单列表失败: {str(e)}")
        return jsonify({'error': '获取订单列表失败，请稍后重试'}), 500

@app.route('/api/withdrawals')
def get_withdrawals():
    """获取提现记录"""
    try:
        # 模拟登录状态
        if 'user_id' not in session:
            return jsonify({'error': '请先登录'}), 401
        
        # 获取提现记录
        withdrawals = MOCK_WITHDRAWALS
        
        # 格式化提现数据
        formatted_withdrawals = []
        for withdrawal in withdrawals:
            formatted_withdrawal = withdrawal.copy()
            formatted_withdrawal['formatted_amount'] = format_price(withdrawal['amount'])
            formatted_withdrawal['formatted_actual_amount'] = format_price(withdrawal['actual_amount'])
            formatted_withdrawal['formatted_fee'] = format_price(withdrawal['fee'])
            formatted_withdrawal['formatted_created_at'] = withdrawal['created_at'].strftime('%Y-%m-%d %H:%M:%S')
            
            if withdrawal['processed_at']:
                formatted_withdrawal['formatted_processed_at'] = withdrawal['processed_at'].strftime('%Y-%m-%d %H:%M:%S')
            else:
                formatted_withdrawal['formatted_processed_at'] = '-'
            
            # 提现方式映射
            method_map = {
                'wechat': '微信零钱',
                'alipay': '支付宝',
                'bank': '银行卡'
            }
            formatted_withdrawal['method_text'] = method_map.get(withdrawal['method'], withdrawal['method'])
            
            # 提现状态映射
            status_map = {
                'pending': '处理中',
                'processing': '处理中',
                'completed': '已完成',
                'failed': '失败'
            }
            formatted_withdrawal['status_text'] = status_map.get(withdrawal['status'], withdrawal['status'])
            
            formatted_withdrawals.append(formatted_withdrawal)
        
        return jsonify(formatted_withdrawals)
        
    except Exception as e:
        logger.error(f"获取提现记录失败: {str(e)}")
        return jsonify({'error': '获取提现记录失败，请稍后重试'}), 500

@app.route('/api/user/balance')
def get_balance():
    """获取用户余额"""
    try:
        # 模拟登录状态
        if 'user_id' not in session:
            return jsonify({'error': '请先登录'}), 401
        
        # 获取用户信息
        user = MOCK_USER
        
        return jsonify({
            'balance': user['balance'],
            'formatted_balance': format_price(user['balance'])
        })
        
    except Exception as e:
        logger.error(f"获取用户余额失败: {str(e)}")
        return jsonify({'error': '获取用户余额失败，请稍后重试'}), 500

@app.route('/api/withdrawal/calculate', methods=['POST'])
def calculate_withdrawal():
    """计算提现金额"""
    try:
        # 获取请求数据
        data = request.get_json()
        amount = data.get('amount', 0)
        
        # 验证提现金额
        if not amount or amount <= 0:
            return jsonify({'error': '提现金额必须大于0'}), 400
        
        if amount < MIN_WITHDRAWAL_AMOUNT:
            return jsonify({'error': f'最低提现金额为{MIN_WITHDRAWAL_AMOUNT}元'}), 400
        
        # 计算实际提现金额和手续费
        actual_amount, fee = calculate_actual_withdrawal(amount)
        
        return jsonify({
            'amount': amount,
            'actual_amount': actual_amount,
            'fee': fee,
            'formatted_amount': format_price(amount),
            'formatted_actual_amount': format_price(actual_amount),
            'formatted_fee': format_price(fee)
        })
        
    except Exception as e:
        logger.error(f"计算提现金额失败: {str(e)}")
        return jsonify({'error': '计算提现金额失败，请稍后重试'}), 500

@app.route('/login')
def login():
    """登录页面"""
    return render_template('login.html')

@app.route('/logout')
def logout():
    """退出登录"""
    session.pop('user_id', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    # 创建静态文件目录
    if not os.path.exists('static'):
        os.makedirs('static')
    
    # 创建模板文件目录
    if not os.path.exists('templates'):
        os.makedirs('templates')
    
    # 启动应用
    app.run(debug=True, host='0.0.0.0', port=5000)